export default function (marker) {
    return {lat: marker.latitude, lng: marker.longitude};
}